# GenAI-powered Q&A Assistant

A real-time web application that enables users to upload documents and ask contextual questions, with responses generated using open-source AI models via prompt engineering.

## Features

- **Document Upload**: Support for text files (PDF and DOCX support coming soon)
- **Contextual Q&A**: Ask questions about uploaded documents
- **AI-Powered Responses**: Uses DistilBERT model from Hugging Face
- **Chat Interface**: Natural conversation-like interaction
- **Confidence Scores**: Shows confidence level of AI responses
- **Document Processing**: Intelligent text chunking and preprocessing
- **Prompt Engineering**: Enhanced context for better responses

## Technology Stack

- **Frontend**: Streamlit
- **AI Model**: DistilBERT (via Hugging Face Inference API)
- **Backend**: Python
- **Document Processing**: Custom text processing and chunking
- **API Integration**: Hugging Face Inference API

## Installation

1. Clone or download the project files
2. Create a virtual environment:
   ```bash
   python3.11 -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Set up your Hugging Face API token:
   - Get a free API token from [Hugging Face](https://huggingface.co/settings/tokens)
   - Update the `HEADERS` variable in `hf_qa.py` with your token

## Usage

1. Start the application:
   ```bash
   streamlit run app.py
   ```

2. Open your browser and navigate to `http://localhost:8501`

3. Upload a text document using the sidebar

4. Ask questions about the document in the chat interface

5. Get AI-powered answers with confidence scores

## Project Structure

```
qna_assistant/
├── app.py                 # Main Streamlit application
├── hf_qa.py              # Hugging Face API integration
├── document_processor.py # Document processing and chunking
├── test_hf_qa.py         # Test script for Q&A functionality
├── requirements.txt      # Python dependencies
├── sample_document.txt   # Sample document for testing
└── README.md            # This file
```

## Key Components

### Document Processing (`document_processor.py`)
- **Text Chunking**: Splits large documents into manageable chunks with overlap
- **Preprocessing**: Cleans and normalizes text for better AI performance
- **Relevance Matching**: Finds the most relevant chunks for each question
- **Prompt Engineering**: Enhances context with instructional prompts

### Q&A Integration (`hf_qa.py`)
- **API Communication**: Handles requests to Hugging Face Inference API
- **Error Handling**: Robust error handling for API calls
- **Response Processing**: Extracts answers and confidence scores

### Streamlit Interface (`app.py`)
- **File Upload**: Drag-and-drop document upload
- **Chat Interface**: Real-time question-answer interaction
- **Session Management**: Maintains chat history and document state
- **User Feedback**: Shows confidence scores and processing information

## Extensibility

The application is designed for easy extension:

### RAG Pipeline Integration
- The chunking system is ready for vector database integration
- Document processing supports multiple retrieval strategies
- Modular design allows easy swapping of AI models

### Vector Search Capabilities
- Text chunks can be easily converted to embeddings
- Similarity search can replace keyword-based chunk selection
- Support for semantic search and better context retrieval

### Multiple Document Support
- Session state management supports multiple documents
- Document processing is modular and scalable
- Easy to extend for document collections

## Future Enhancements

1. **PDF and DOCX Support**: Full document format support
2. **Vector Database**: Integration with Chroma or Pinecone
3. **Multiple Models**: Support for different AI models
4. **Advanced RAG**: Sophisticated retrieval-augmented generation
5. **User Authentication**: Multi-user support with authentication
6. **Document Management**: Upload, delete, and manage multiple documents
7. **Export Features**: Export conversations and answers

## Testing

Run the test script to verify the Q&A functionality:

```bash
python test_hf_qa.py
```

## Troubleshooting

### Common Issues

1. **API Token Error**: Ensure your Hugging Face API token is valid and has proper permissions
2. **File Upload Issues**: Currently only text files are supported
3. **Slow Responses**: The free Hugging Face API may have rate limits

### Performance Tips

1. **Document Size**: Keep documents under 10,000 words for optimal performance
2. **Question Clarity**: Ask specific questions for better results
3. **Context Relevance**: Ensure questions are related to the uploaded document

## License

This project is open source and available under the MIT License.

## Contributing

Contributions are welcome! Please feel free to submit pull requests or open issues for bugs and feature requests.

## Acknowledgments

- Hugging Face for providing free access to AI models
- Streamlit for the excellent web framework
- DistilBERT team for the efficient Q&A model

